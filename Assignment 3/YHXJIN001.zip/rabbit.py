# rabbit.py
# A program to print out cute bunnies
# Jing Yeh 
# 1st March 2023

print('''
(\\\\               (\/)      
( '')    (\_/)   (.. )   //)
O(")(") (\\'.'/) (")(")O (" )
        (")_(")        ()()o      
''')